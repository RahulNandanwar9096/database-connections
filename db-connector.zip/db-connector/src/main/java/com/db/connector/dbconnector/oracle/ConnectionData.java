package com.db.connector.dbconnector.oracle;

public class ConnectionData {

	private String host;
	private String port;
	private String sid;
	private String user;
	private String password;
	private String status;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ConnectionData [host=" + host + ", port=" + port + ", sid=" + sid + ", user=" + user + ", password="
				+ password + ", status=" + status + "]";
	}

}
