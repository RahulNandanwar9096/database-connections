package com.db.connector.dbconnector.oracle;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Connector {

	public static List<ConnectionData> verify() throws JsonParseException, JsonMappingException, IOException {
		List<ConnectionData> connections = readConnectionJSON();
		connections.forEach(connection -> {
			try {
				connection.setStatus(getConnection(connection.getHost(), connection.getPort(), connection.getSid(),
						connection.getUser(), connection.getPassword()));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		return connections;
	}

	private static List<ConnectionData> readConnectionJSON()
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		File file = new File("db-connections.json");
		return objectMapper.readValue(file, new TypeReference<List<ConnectionData>>() {
		});
	}

	private static String getConnection(String host, String port, String sid, String user, String password)
			throws ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system",
				"Password123")) {

			if (conn != null) {
				System.out.println("Connected to the database!");
				return "SUCCESS";
			} else {
				System.out.println("Failed to make connection!");
			}

		} catch (SQLException e) {
			System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "FAILED";
	}

}
