package com.db.connector.dbconnector.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import com.db.connector.dbconnector.oracle.ConnectionData;
import com.db.connector.dbconnector.oracle.Connector;

@Controller
public class DBConnectionController {

	@GetMapping(value = "/db-connection", produces = MediaType.TEXT_HTML_VALUE)
	public String dbConnection(ModelMap model) {
		try {
			List<ConnectionData> connections = Connector.verify();
			System.out.println("  connections  " + connections.toString());
			model.put("connections", connections);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "db-connection";
	}
}
