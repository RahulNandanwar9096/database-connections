package com.db.connector.dbconnector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbConnectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
